<!-- -------------------------------------------------------------------
Copyright (c) 2026 Ved Talmaley. All Rights Reserved.
This project and its source code are strictly proprietary.
Unauthorized copying, distribution, or use is strictly prohibited.
------------------------------------------------------------------- -->

---
title: Quantumlens Embedder
emoji: 🏃
colorFrom: indigo
colorTo: yellow
sdk: gradio
sdk_version: 6.20.0
python_version: '3.12'
app_file: app.py
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference

---

# Hugging Face Space Deployment configuration

This folder contains the deployable assets for hosting the **QuantumLens Embedder** service on a Hugging Face Space.

## Space Settings Summary

| Parameter | Configuration | Details |
| :--- | :--- | :--- |
| **Title** | `Quantumlens Embedder` | Identifies the space name on HF Hub. |
| **Emoji** | `🏃` (Runner) | App icon representer. |
| **Color Scheme** | `indigo` ──► `yellow` | Portal accent colors. |
| **SDK Type** | `gradio` | Interface framework SDK. |
| **SDK Version** | `6.20.0` | Target gradio compilation version. |
| **Python Version**| `3.12` | Runtime execution platform. |
| **Entrypoint File**| `app.py` | Initial startup module path. |
| **License** | `MIT` | Open-source licensing agreement. |

---

## Related Documentation
* [Microservice Readme](../README%20copy.md): API endpoint descriptions.
* [System Architecture Spec](../../docs/architecture/architecture.md): Systems layers overview.
