<!-- -------------------------------------------------------------------
Copyright (c) 2026 Ved Talmaley. All Rights Reserved.
This project and its source code are strictly proprietary.
Unauthorized copying, distribution, or use is strictly prohibited.
------------------------------------------------------------------- -->

# QuantumLens Embedder Service (services/)

This microservice provides high-throughput dense vector embedding generation for **QuantumLens**. It encodes text fields (KPI configurations, row descriptors) into 384-dimensional spaces to enable cosine similarity lookups in ChromaDB.

For backend API details, see the primary [README.md](../README.md). For detailed system flows, see [architecture.md](../docs/architecture/architecture.md).

---

## Technical Stack & Model

| Attribute | Selection | Purpose |
| :--- | :--- | :--- |
| **Model Card** | **BAAI/bge-small-en-v1.5** | High-performance, compact embedding model (384 dimensions) optimized for retrieval-augmented generation. |
| **Framework** | FastAPI / Python 3.12 | ASGI microservice API hosting. |
| **Inference Engine** | SentenceTransformers | Local tensor calculations and text encoding. |

---

## Getting Started

### Local Setup & Start Guide

| Step | Phase | Shell Command | Notes |
| :--- | :--- | :--- | :--- |
| **1** | Navigate Directory | `cd services/` | Go to the services folder. |
| **2** | Install Modules | `pip install -r requirements.txt` | Installs `sentence-transformers`, `fastapi`, `uvicorn`. |
| **3** | Start Service | `uvicorn embedding-service.app:app --reload --port 8001` | Runs the API reloading server on port 8001. |

---

## API Endpoints Reference

### Endpoints Matrix
| Method | Route | Description | Input | Output | Success Code |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `GET` | `/` | Microservice metadata check | None | JSON details | `200 OK` |
| `GET` | `/health` | Ingestion status check | None | `{"status": "healthy"}` | `200 OK` |
| `POST` | `/embed` | Vector calculation endpoint | JSON list of texts | JSON list of embeddings | `200 OK` |

---

### Inferences Payload Specifications

#### POST `/embed`

##### Request JSON Structure
| Field | Type | Required | Description | Example Payload |
| :--- | :--- | :--- | :--- | :--- |
| **texts** | Array of Strings | YES | Sentences to calculate embeddings for. | `{"texts": ["Revenue", "Net Interest Income"]}` |

##### Response JSON Structure
| Field | Type | Description | Example Payload |
| :--- | :--- | :--- | :--- |
| **embeddings** | Array of Arrays | Ordered list of 384-dimensional floating point vectors. | `{"embeddings": [[0.0125, -0.0934, ...], [...]]}` |

---

## Related Documentation
* [Root Readme](../README.md): Backend REST APIs.
* [System Architecture Spec](../docs/architecture/architecture.md): Visual layer flows.